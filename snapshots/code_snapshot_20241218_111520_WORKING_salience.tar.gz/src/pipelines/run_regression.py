# src/pipelines/run_regression.py (UPDATED with looped IG generation and interactive plot)

import os
import json
import logging
import numpy as np
import torch
from torch.utils.data import DataLoader, Subset
import optuna
from sklearn.model_selection import train_test_split
import ast
import pandas as pd

from src.config import PREPARED_DATA_CSV
from src.models.datasets import SequenceDataset, collate_fn
from src.models.deep_learning import SeqCNNRegressor, train_model, predict_model
from src.evaluation.metrics import evaluate_regression
from src.evaluation.visualization import (
    plot_distribution, 
    plot_pred_vs_actual, 
    plot_pred_vs_actual_interactive
)
from src.reporting.generate_report import generate_html_report

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info("Starting sequence-based regression pipeline...")

batch_size = 32
epochs = 20
early_stop_patience = 5
device = 'cuda' if torch.cuda.is_available() else 'cpu'

# Load dataset and create splits
dataset = SequenceDataset(PREPARED_DATA_CSV)
num_samples = len(dataset)
indices = np.arange(num_samples)
np.random.seed(42)
np.random.shuffle(indices)

train_end = int(0.7 * num_samples)
val_end = int(0.85 * num_samples)

train_indices = indices[:train_end]
val_indices = indices[train_end:val_end]
test_indices = indices[val_end:]

train_dataset = Subset(dataset, train_indices)
val_dataset = Subset(dataset, val_indices)
test_dataset = Subset(dataset, test_indices)

train_loader_for_tuning = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_fn)
val_loader_for_tuning = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_fn)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_fn)

def objective(trial):
    # Hyperparameters for training
    lr = trial.suggest_float("lr", 1e-4, 1e-2, log=True)
    weight_decay = trial.suggest_float("weight_decay", 1e-6, 1e-4, log=True)

    # Hyperparameters for model architecture
    filters_per_branch = trial.suggest_int("filters_per_branch", 32, 128, step=32)
    kernel_sizes_str = trial.suggest_categorical("kernel_sizes", ["3,5,7", "3,7", "5,9"])
    kernel_sizes = tuple(map(int, kernel_sizes_str.split(',')))    
    fc_units = trial.suggest_int("fc_units", 32, 128, step=32)
    dropout_rate = trial.suggest_float("dropout_rate", 0.0, 0.7, step=0.1)
    use_batchnorm = trial.suggest_categorical("use_batchnorm", [True, False])

    model = SeqCNNRegressor(
        kernel_sizes=kernel_sizes,
        filters_per_branch=filters_per_branch,
        fc_units=fc_units,
        dropout_rate=dropout_rate,
        use_batchnorm=use_batchnorm
    )

    train_model(model, train_loader_for_tuning, val_loader_for_tuning,
                epochs=epochs, lr=lr, weight_decay=weight_decay,
                device=device, early_stop_patience=early_stop_patience)
    
    model.load_state_dict(torch.load("best_model.pth", map_location=device, weights_only=True))

    y_val_pred = predict_model(model, val_loader_for_tuning, device=device)
    y_val = [y.item() for _, y in val_dataset]
    y_val = np.array(y_val)
    val_metrics = evaluate_regression(y_val, y_val_pred)

    return val_metrics['mse']

study = optuna.create_study(direction="minimize")
study.optimize(objective, n_trials=50, timeout=None)

logger.info(f"Best trial: {study.best_trial.number}")
logger.info(f"Best trial params: {study.best_params}")
logger.info(f"Best trial validation MSE: {study.best_value}")

best_params = study.best_params

# Convert kernel_sizes back to tuple of ints if needed
kernel_sizes_str = best_params["kernel_sizes"]
if isinstance(kernel_sizes_str, str):
    kernel_sizes = ast.literal_eval(kernel_sizes_str)
else:
    kernel_sizes = kernel_sizes_str

final_model = SeqCNNRegressor(
    kernel_sizes=kernel_sizes,
    filters_per_branch=best_params["filters_per_branch"],
    fc_units=best_params["fc_units"],
    dropout_rate=best_params["dropout_rate"],
    use_batchnorm=best_params["use_batchnorm"]
)

train_model(final_model, train_loader_for_tuning, val_loader_for_tuning,
            epochs=epochs, lr=best_params["lr"],
            weight_decay=best_params["weight_decay"],
            device=device, early_stop_patience=early_stop_patience)

final_model.load_state_dict(torch.load("best_model.pth", map_location=device, weights_only=True))

y_test_pred = predict_model(final_model, test_loader, device=device)
y_test = [y.item() for _, y in test_dataset]
y_test = np.array(y_test)

test_metrics = evaluate_regression(y_test, y_test_pred)
logger.info(f"Test metrics with best hyperparameters: {test_metrics}")

os.makedirs("report/regression_plots", exist_ok=True)
plot_distribution(y_test, "Distribution of Test Scores", "report/regression_plots/test_score_distribution.png")
plot_pred_vs_actual(y_test, y_test_pred, "CNN Predictions", "report/regression_plots/cnn_pred_vs_actual.png")

regression_results = {
    "CNN_Model": test_metrics
}
plots = {
    "test_score_distribution": "regression_plots/test_score_distribution.png",
    "cnn_pred_vs_actual": "regression_plots/cnn_pred_vs_actual.png"
}

classification_results = {}
data_exploration_plots = {}

# === Explainability Integration Start ===
logger.info("Starting Integrated Gradients explainability...")

from captum.attr import IntegratedGradients
import matplotlib.pyplot as plt
import seaborn as sns

final_model.eval()
final_model.to(device)

X_batch, y_batch, mask_batch = next(iter(test_loader))
X_batch = X_batch.to(device)  # shape: (batch, 4, seq_len)
y_batch = y_batch.to(device)

def forward_fn(x):
    return final_model(x)

ig = IntegratedGradients(forward_fn)

os.makedirs("report/explainability", exist_ok=True)

original_df = pd.read_csv(PREPARED_DATA_CSV)
test_df = original_df.iloc[test_indices]

global_sample_idx = 0
for batch_idx, (X_batch, y_batch, mask_batch) in enumerate(test_loader):
    X_batch = X_batch.to(device)
    y_batch = y_batch.to(device)
    
    batch_size_current = X_batch.size(0)
    for i in range(batch_size_current):
        input_sample = X_batch[i:i+1]
        true_score = y_batch[i].item()

        baseline = torch.zeros_like(input_sample)
        attributions = ig.attribute(input_sample, baseline, target=0)
        attributions = attributions.detach().cpu().numpy().squeeze(0)  # (4, seq_len)

        # Retrieve start/end for this sample from test_df
        start_val = test_df.iloc[global_sample_idx]['start']
        end_val = test_df.iloc[global_sample_idx]['end']

        npy_path = f"report/explainability/attributions_sample_{global_sample_idx}.npy"
        np.save(npy_path, attributions)

        attr_plot_path = f"report/explainability/integrated_gradients_heatmap_sample_{global_sample_idx}.png"
        plt.figure(figsize=(12, 3))
        sns.heatmap(attributions, cmap='cividis', center=0, yticklabels=['A','C','G','T']) # Color options: 'viridis', 'plasma', 'inferno', 'magma', 'cividis', 'Blues', 'Greens', 'Reds', 'Purples', 'Oranges'
        plt.xlabel("Sequence Position")
        plt.ylabel("Nucleotide Channel")
        plt.title(
            f"IG for Sample {global_sample_idx}, True={true_score:.3f}, "
            f"Pred={y_test_pred[global_sample_idx]:.3f}, Start={start_val}, End={end_val}"
        )
        plt.tight_layout()
        plt.savefig(attr_plot_path, dpi=150)
        plt.close()

        plots[f"ig_heatmap_sample_{global_sample_idx}"] = f"explainability/integrated_gradients_heatmap_sample_{global_sample_idx}.png"

        global_sample_idx += 1

# === Explainability Integration End ===

# Construct a DataFrame for the interactive plot
interactive_df = pd.DataFrame({
    "True": y_test,
    "Pred": y_test_pred,
    "Sequence": test_df['sequence'].values,
    "Start": test_df['start'].values,
    "End": test_df['end'].values,
    "SampleIndex": range(len(y_test))
})

# For IG paths, use the same logic as before
ig_paths = []
for i in range(len(y_test)):
    ig_path = f"explainability/integrated_gradients_heatmap_sample_{i}.png"
    if os.path.exists(os.path.join("report", ig_path)):
        ig_paths.append(ig_path)
    else:
        ig_paths.append("No IG available")

interactive_df["IG_Path"] = ig_paths

interactive_plot_path = "report/regression_plots/cnn_pred_vs_actual_interactive.html"
plot_pred_vs_actual_interactive(interactive_df, "CNN Predictions (Interactive)", interactive_plot_path)

plots["cnn_pred_vs_actual_interactive"] = "regression_plots/cnn_pred_vs_actual_interactive.html"

generate_html_report(
    regression_results=regression_results,
    classification_results=classification_results,
    data_exploration_plots=data_exploration_plots,
    plots=plots,
    output_path="report/index.html"
)

logger.info("Sequence-based regression pipeline completed with explainability and interactive plot. Report generated.")
