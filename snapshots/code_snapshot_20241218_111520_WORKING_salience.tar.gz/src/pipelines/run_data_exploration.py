# run_data_exploration.py

import os
import json
import logging
import pandas as pd
from src.config import FEATURE_DATA_CSV
from src.utils.file_utils import load_csv
from src.evaluation.visualization import plot_correlation_heatmap, plot_feature_distributions

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info("Starting data and feature exploration pipeline...")

# Load the feature data
df = load_csv(FEATURE_DATA_CSV)
logger.info("Feature data loaded successfully.")

exclude_cols = ['chrom']
if 'sequence' in df.columns:
    exclude_cols.append('sequence')

numeric_features = [col for col in df.columns if col not in exclude_cols and pd.api.types.is_numeric_dtype(df[col])]

# Create output directories
os.makedirs("report/data_exploration_plots", exist_ok=True)

# Plot correlation heatmap of numeric features
corr_heatmap_path_full = "report/data_exploration_plots/feature_correlation_heatmap.png"
plot_correlation_heatmap(df[numeric_features], "Feature Correlation Heatmap", corr_heatmap_path_full)

# Plot distributions of each numeric feature
feature_dist_dir_full = "report/data_exploration_plots/features"
feature_dist_plots_full = plot_feature_distributions(df, numeric_features, feature_dist_dir_full)

# Remove the 'report/' prefix for JSON storage
corr_heatmap_path = "data_exploration_plots/feature_correlation_heatmap.png"
feature_dist_plots = {f: p.replace("report/", "") for f, p in feature_dist_plots_full.items()}

data_exploration_plots = {
    "correlation_heatmap": corr_heatmap_path,
    "feature_distributions": feature_dist_plots
}

# Save to JSON
with open("report/data_exploration_plots.json", 'w') as f:
    json.dump(data_exploration_plots, f, indent=4)

logger.info("Data exploration plots saved as JSON.")

# Generate text-based summary report
summary_report_path = "report/data_exploration_summary.txt"

desc = df[numeric_features].describe(include='all')
corr_matrix = df[numeric_features].corr()

corr_pairs = corr_matrix.unstack().dropna()
corr_pairs = corr_pairs[corr_pairs.index.get_level_values(0) != corr_pairs.index.get_level_values(1)]
top_positive_correlations = corr_pairs.sort_values(ascending=False).head(10)
top_negative_correlations = corr_pairs.sort_values(ascending=True).head(10)

with open(summary_report_path, "w") as report_file:
    report_file.write("=== Data Exploration Summary ===\n\n")
    report_file.write("**Numeric Features:**\n")
    report_file.write(", ".join(numeric_features) + "\n\n")

    report_file.write("**Summary Statistics (Numeric Features):**\n")
    report_file.write(desc.to_string() + "\n\n")

    report_file.write("**Top 10 Positive Correlations:**\n")
    for (f1, f2), value in top_positive_correlations.items():
        report_file.write(f"{f1} and {f2}: {value:.3f}\n")
    report_file.write("\n")

    report_file.write("**Top 10 Negative Correlations:**\n")
    for (f1, f2), value in top_negative_correlations.items():
        report_file.write(f"{f1} and {f2}: {value:.3f}\n")
    report_file.write("\n")

    report_file.write("**Observations: **\n")
    report_file.write("1. Review correlations to identify strong relationships.\n")
    report_file.write("2. The summary statistics provide distribution insights.\n")
    report_file.write("3. Feature distribution plots are in 'report/data_exploration_plots/features'.\n")

logger.info(f"Data exploration summary saved at {summary_report_path}.")
logger.info("Data exploration pipeline completed.")
