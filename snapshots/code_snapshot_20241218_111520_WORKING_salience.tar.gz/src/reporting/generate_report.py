# src/reporting/generate_report.py
import os
import re

def generate_html_report(
    regression_results,
    classification_results,
    data_exploration_plots,
    plots,
    output_path
):
    """
    Generate a comprehensive HTML report, now with multiple IG heatmaps sorted numerically.
    """

    # Map plot keys to human-readable titles
    plot_titles = {
        "correlation_heatmap": "Feature and Methylation Score Correlation Heatmap",
        "test_score_distribution": "Distribution of Test Methylation Scores",
        "cnn_pred_vs_actual": "CNN Predictions vs Actual Methylation Scores",
        "class_label_distribution": "Distribution of Class Labels",
        "lr_roc": "Logistic Regression ROC Curve",
        "rf_roc": "Random Forest ROC Curve",
        "mlp_roc": "MLP ROC Curve",
        "ensemble_roc": "Ensemble ROC Curve",
        "ig_heatmap": "Integrated Gradients Attribution Heatmap"
    }

    regression_plot_keys = ["test_score_distribution", "cnn_pred_vs_actual"]
    classification_plot_keys = ["class_label_distribution", "lr_roc", "rf_roc", "mlp_roc", "ensemble_roc"]

    # Construct regression results table
    regression_table = (
        "<table class='metric-table'>"
        "<tr><th>Model</th><th>MSE</th><th>R²</th><th>Pearson Corr</th></tr>"
    )
    for model, metrics in regression_results.items():
        regression_table += (
            f"<tr><td>{model}</td>"
            f"<td>{metrics['mse']:.4f}</td>"
            f"<td>{metrics['r2']:.4f}</td>"
            f"<td>{metrics['pearson_corr']:.4f}</td></tr>"
        )
    regression_table += "</table>"

    # Construct classification results table
    classification_table = (
        "<table class='metric-table'>"
        "<tr><th>Model</th><th>AUC</th><th>Accuracy</th>"
        "<th>F1</th><th>Precision</th><th>Recall</th></tr>"
    )
    for model, metrics in classification_results.items():
        classification_table += (
            f"<tr><td>{model}</td>"
            f"<td>{metrics.get('auc', 0.0):.4f}</td>"
            f"<td>{metrics.get('accuracy',0.0):.4f}</td>"
            f"<td>{metrics.get('f1',0.0):.4f}</td>"
            f"<td>{metrics.get('precision',0.0):.4f}</td>"
            f"<td>{metrics.get('recall',0.0):.4f}</td></tr>"
        )
    classification_table += "</table>"

    # Data exploration section
    data_exploration_html = "<h2>Data and Feature Exploration</h2>"
    data_exploration_html += (
        "<p>Below are insights into the relationships between features and the methylation score, "
        "including a correlation heatmap that now incorporates methylation scores.</p>"
    )
    if "correlation_heatmap" in data_exploration_plots:
        corr_path = data_exploration_plots["correlation_heatmap"]
        title = plot_titles.get("correlation_heatmap", "Feature Correlation Heatmap")
        data_exploration_html += f"<h3>{title}</h3><img src='{corr_path}' alt='{title}'>"
    if "feature_distributions" in data_exploration_plots:
        data_exploration_html += "<h3>Feature Distributions</h3><p>Each plot shows the distribution of a particular feature.</p>"
        for feature, fpath in data_exploration_plots["feature_distributions"].items():
            data_exploration_html += f"<h4>{feature}</h4><img src='{fpath}' alt='{feature}_distribution'>"

    # Regression and classification sections
    regression_html = (
        "<h2>Regression Performance</h2>"
        "<p>The table below presents performance metrics for the regression models that predict continuous methylation levels. "
        "Following the table, we include plots illustrating regression model predictions and score distributions.</p>"
        f"{regression_table}"
    )

    classification_html = (
        "<h2>Classification Performance</h2>"
        "<p>The table below presents performance metrics for classification models that predict whether samples exceed a given methylation score threshold. "
        "Following the table, ROC curves and distribution plots are provided.</p>"
        f"{classification_table}"
    )

    # Regression plots
    regression_plots_html = "<h2>Regression Plots</h2>"
    for plot_name in regression_plot_keys:
        if plot_name in plots:
            formatted_name = plot_titles.get(plot_name, plot_name.replace('_', ' ').title())
            regression_plots_html += f"<h3>{formatted_name}</h3><img src='{plots[plot_name]}' alt='{formatted_name}'>"

    # Check if there's an interactive version of the CNN plot
    if "cnn_pred_vs_actual_interactive" in plots:
        regression_plots_html += (
            "<h3>Interactive Version</h3>"
            f"<p><a href='{plots['cnn_pred_vs_actual_interactive']}'>Open Interactive Plot</a></p>"
        )

    # Classification plots
    classification_plots_html = "<h2>Classification Plots</h2>"
    for plot_name in classification_plot_keys:
        if plot_name in plots:
            formatted_name = plot_titles.get(plot_name, plot_name.replace('_', ' ').title())
            classification_plots_html += f"<h3>{formatted_name}</h3><img src='{plots[plot_name]}' alt='{formatted_name}'>"

    # Explainability section
    ig_keys = [k for k in plots.keys() if k.startswith("ig_heatmap_sample_") or k == "ig_heatmap"]

    def extract_index(key):
        match = re.search(r"ig_heatmap_sample_(\d+)", key)
        if match:
            return int(match.group(1))
        else:
            # If it's just "ig_heatmap" without an index, put it at the front
            return -1

    ig_keys_sorted = sorted(ig_keys, key=extract_index)

    explainability_html = ""
    if ig_keys_sorted:
        explainability_html += "<h2>Explainability (Integrated Gradients)</h2>"
        explainability_html += (
            "<p>Below are heatmaps showing the attributions computed by Integrated Gradients for selected test samples. "
            "Positive values (red) indicate features that increased the prediction, while negative values (blue) indicate features "
            "that decreased it. The attributions are also saved in <code>report/explainability/</code> as .npy files for further analysis.</p>"
        )
        for ig_key in ig_keys_sorted:
            ig_title = plot_titles.get("ig_heatmap", "Integrated Gradients Heatmap")
            if ig_key == "ig_heatmap":
                explainability_html += f"<h3>{ig_title}</h3>"
            else:
                sample_idx = extract_index(ig_key)
                explainability_html += f"<h3>{ig_title} (Sample {sample_idx})</h3>"
            explainability_html += f"<img src='{plots[ig_key]}' alt='{ig_title}'>"

    html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Methylation Prediction Report</title>
<style>
body {{
    font-family: Arial, sans-serif;
    margin: 20px;
    color: #333;
}}
h1 {{
    color: #333;
}}
.metric-table {{
    border-collapse: collapse;
    margin: 20px 0;
    width: 60%;
}}
.metric-table th, .metric-table td {{
    border: 1px solid #ccc;
    padding: 8px 12px;
    text-align: center;
}}
.metric-table th {{
    background-color: #f4f4f4;
}}
img {{
    max-width: 600px;
    height: auto;
    display: block;
    margin: 20px 0;
}}
</style>
</head>
<body>
<h1>Methylation Prediction Report</h1>
<p>This report presents a comprehensive overview of both regression and classification models used to predict and classify methylation levels, "
"including explainability using Integrated Gradients. It also includes data exploration results.</p>

{data_exploration_html}

{regression_html}

{regression_plots_html}

{classification_html}

{classification_plots_html}

{explainability_html}

<p>In summary, the Random Forest approach often provides robust performance, and the CNN-based regressor shows promising results. The integrated gradients analysis provides insights into which parts of the sequence the model relies on most, guiding potential feature engineering and model improvements.</p>

</body>
</html>
"""

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        f.write(html_content)

    print(f"Report generated at: {output_path}")
