# src/reporting/__init__.py
from .generate_report import generate_html_report
