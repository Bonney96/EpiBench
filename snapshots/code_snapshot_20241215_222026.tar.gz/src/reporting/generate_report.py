# generate_report.py

import os

def generate_html_report(regression_results, classification_results, plots, output_path):
    """
    regression_results: dict of model_name -> {mse, r2, pearson_corr}
    classification_results: dict of model_name -> {auc, accuracy, f1, precision, recall}
    plots: dict containing file paths of generated plots (keys like 'distribution', 'pred_vs_actual_lr', etc.)
    output_path: path to the final HTML file
    """
    
    # Create a simple HTML table for regression
    regression_table = "<table class='metric-table'><tr><th>Model</th><th>MSE</th><th>R²</th><th>Pearson Corr</th></tr>"
    for model, metrics in regression_results.items():
        regression_table += f"<tr><td>{model}</td><td>{metrics['mse']:.4f}</td><td>{metrics['r2']:.4f}</td><td>{metrics['pearson_corr']:.4f}</td></tr>"
    regression_table += "</table>"

    # Create a simple HTML table for classification
    classification_table = "<table class='metric-table'><tr><th>Model</th><th>AUC</th><th>Accuracy</th><th>F1</th><th>Precision</th><th>Recall</th></tr>"
    for model, metrics in classification_results.items():
        classification_table += f"<tr><td>{model}</td><td>{metrics['auc']:.4f}</td><td>{metrics['accuracy']:.4f}</td><td>{metrics['f1']:.4f}</td><td>{metrics['precision']:.4f}</td><td>{metrics['recall']:.4f}</td></tr>"
    classification_table += "</table>"

    # Insert images into the HTML report
    # Example: plot keys: 'score_distribution', 'lr_pred_vs_actual', 'rf_pred_vs_actual', 'cnn_pred_vs_actual', 'roc_lr'
    images_html = ""
    for plot_name, plot_path in plots.items():
        images_html += f"<h3>{plot_name.replace('_',' ').title()}</h3><img src='{plot_path}' alt='{plot_name}'>"

    html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Methylation Prediction Report</title>
<style>
body {{
    font-family: Arial, sans-serif;
    margin: 20px;
}}
h1 {{
    color: #333;
}}
.metric-table {{
    border-collapse: collapse;
    margin: 20px 0;
    width: 60%;
}}
.metric-table th, .metric-table td {{
    border: 1px solid #ccc;
    padding: 8px 12px;
    text-align: center;
}}
.metric-table th {{
    background-color: #f4f4f4;
}}
img {{
    max-width: 600px;
    height: auto;
    display: block;
    margin: 20px 0;
}}
</style>
</head>
<body>
<h1>Methylation Prediction Report</h1>
<p>This report compares multiple models for both regression and classification tasks.</p>

<h2>Regression Performance</h2>
{regression_table}

<h2>Classification Performance</h2>
{classification_table}

<h2>Plots</h2>
{images_html}

<p>The Random Forest approach often provides strong performance, as seen in both regression and classification results.</p>

</body>
</html>
"""

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        f.write(html_content)
    print(f"Report generated at: {output_path}")
