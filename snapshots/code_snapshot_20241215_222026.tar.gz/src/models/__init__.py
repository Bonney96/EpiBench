# src/models/__init__.py
# Re-export model training functions and classes to access them easily.

from .classical import (
    train_linear_regression, predict_linear_regression,
    train_random_forest_regressor, predict_random_forest_regressor,
    train_logistic_regression, predict_logistic_regression,
    train_random_forest_classifier, predict_random_forest_classifier
)

from .deep_learning import (
    CNNRegressor, train_deep_model, predict_deep_model,
    RNNRegressor, TransformerRegressor
)

from .datasets import SequenceDataset
