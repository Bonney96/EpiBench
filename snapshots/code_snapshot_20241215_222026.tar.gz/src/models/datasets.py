# datasets.py
import torch
from torch.utils.data import Dataset
import numpy as np

class SequenceDataset(Dataset):
    """
    A PyTorch Dataset for sequences.
    """
    def __init__(self, df, seq_length, target_col='score', classification=False, threshold=0.5):
        """
        df: DataFrame containing 'sequence' and 'score' columns, plus features if needed.
        seq_length: Fixed length of sequences.
        classification: If True, prepare binary classification targets.
        threshold: Threshold for binary classification.
        """
        self.df = df.reset_index(drop=True)
        self.seq_length = seq_length
        self.classification = classification
        self.threshold = threshold

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        seq = row['sequence']
        X_seq = self.one_hot_encode(seq, self.seq_length)
        y = row['score']
        if self.classification:
            y = 1 if y > self.threshold else 0
        return X_seq, y

    def one_hot_encode(self, seq, fixed_len):
        seq = seq.upper()
        mapping = {'A':0, 'C':1, 'G':2, 'T':3}
        arr = np.zeros((4, fixed_len), dtype=np.float32)
        seq = seq[:fixed_len]
        if len(seq) < fixed_len:
            seq = seq + 'A'*(fixed_len - len(seq))
        for i, base in enumerate(seq):
            arr[mapping.get(base, 0), i] = 1.0
        return arr
