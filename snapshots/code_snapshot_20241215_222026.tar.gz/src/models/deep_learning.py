# deep_learning.py

import torch
import torch.nn as nn
import torch.optim as optim

# Example CNN model for regression
class CNNRegressor(nn.Module):
    def __init__(self, input_channels=4, seq_len=100):
        super(CNNRegressor, self).__init__()
        self.conv1 = nn.Conv1d(input_channels, 32, kernel_size=7, padding=3)
        self.bn1 = nn.BatchNorm1d(32)
        self.relu = nn.ReLU()
        self.pool = nn.MaxPool1d(kernel_size=2)
        self.conv2 = nn.Conv1d(32, 64, kernel_size=7, padding=3)
        self.bn2 = nn.BatchNorm1d(64)
        
        # Assume seq_len halved twice by pooling (seq_len/4)
        self.fc1 = nn.Linear((seq_len//4)*64, 64)
        self.fc2 = nn.Linear(64, 1)
        self.dropout = nn.Dropout(0.5)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.pool(x)
        
        x = self.conv2(x)
        x = self.bn2(x)
        x = self.relu(x)
        x = self.pool(x)
        
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x

def train_deep_model(model, train_loader, val_loader, epochs=10, lr=0.001, device='cpu'):
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    model.to(device)
    
    best_val_loss = float('inf')
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device, dtype=torch.float32).unsqueeze(1)
            optimizer.zero_grad()
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        
        avg_train_loss = total_loss / len(train_loader)
        
        # Validation
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch = X_batch.to(device)
                y_batch = y_batch.to(device, dtype=torch.float32).unsqueeze(1)
                outputs = model(X_batch)
                loss = criterion(outputs, y_batch)
                val_loss += loss.item()
        avg_val_loss = val_loss / len(val_loader)
        
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            # Save model state if improving
            torch.save(model.state_dict(), "best_model.pth")
        
        print(f"Epoch {epoch+1}: Train Loss {avg_train_loss:.4f}, Val Loss {avg_val_loss:.4f}")

def predict_deep_model(model, test_loader, device='cpu'):
    model.to(device)
    model.eval()
    preds = []
    with torch.no_grad():
        for X_batch, _ in test_loader:
            X_batch = X_batch.to(device)
            outputs = model(X_batch)
            preds.extend(outputs.squeeze(1).cpu().tolist())
    return preds

class RNNRegressor(nn.Module):
    """A simple RNN-based model for regression."""
    def __init__(self, input_size=4, hidden_size=64, num_layers=1, seq_len=100):
        super(RNNRegressor, self).__init__()
        self.rnn = nn.LSTM(input_size, hidden_size, num_layers=batch_first=True)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # x: (batch, channels, seq_len) -> we want (batch, seq_len, channels)
        x = x.permute(0, 2, 1)  # now (batch, seq_len, channels)
        _, (hn, _) = self.rnn(x)
        # hn: (num_layers, batch, hidden_size)
        # Take last hidden state of the last layer:
        out = self.fc(hn[-1])
        return out

class TransformerRegressor(nn.Module):
    """A simple Transformer-based model for regression."""
    def __init__(self, input_dim=4, d_model=64, nhead=4, num_layers=2, seq_len=100):
        super(TransformerRegressor, self).__init__()
        self.embedding = nn.Linear(input_dim, d_model)
        encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.fc = nn.Linear(d_model, 1)
        
    def forward(self, x):
        # x: (batch, channels, seq_len)
        # Transform to (seq_len, batch, d_model)
        x = x.permute(2, 0, 1)  
        x = self.embedding(x)  
        # pass through transformer
        out = self.transformer_encoder(x)  # (seq_len, batch, d_model)
        # Take the mean across seq_len
        out = out.mean(dim=0)  # (batch, d_model)
        out = self.fc(out)
        return out