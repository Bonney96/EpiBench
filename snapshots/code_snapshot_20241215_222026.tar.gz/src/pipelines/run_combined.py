# run_combined.py
import json
import os
from src.reporting.generate_report import generate_html_report

# Assume `run_regression.py` and `run_classification.py` have been updated 
# to save their metrics and plot paths to JSON files for easier integration.

# 1. Run regression pipeline
os.system("python src/pipelines/run_regression.py")

# 2. Run classification pipeline
os.system("python src/pipelines/run_classification.py")

# 3. Load saved metrics and plots
with open("report/regression_metrics.json", 'r') as f:
    regression_results = json.load(f)

with open("report/regression_plots.json", 'r') as f:
    regression_plots = json.load(f)

with open("report/classification_metrics.json", 'r') as f:
    classification_results = json.load(f)

with open("report/classification_plots.json", 'r') as f:
    classification_plots = json.load(f)

# Combine plots (if you wish to display all)
all_plots = {**regression_plots, **classification_plots}

# Generate a combined report
generate_html_report(
    regression_results=regression_results,
    classification_results=classification_results,
    plots=all_plots,
    output_path="report/combined_report.html"
)

print("Combined report generated at: report/combined_report.html")
