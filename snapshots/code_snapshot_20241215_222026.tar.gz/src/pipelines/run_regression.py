# run_regression.py
import os
import json
import logging
import numpy as np
from sklearn.model_selection import train_test_split
from src.config import FEATURE_DATA_CSV
from src.utils.file_utils import load_csv
from src.models.classical import (
    train_linear_regression, predict_linear_regression,
    train_random_forest_regressor, predict_random_forest_regressor
)
from src.models.deep_learning import CNNRegressor, train_deep_model, predict_deep_model
from src.evaluation.metrics import evaluate_regression
from src.evaluation.visualization import plot_distribution, plot_pred_vs_actual
import torch
from torch.utils.data import TensorDataset, DataLoader

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info("Starting regression pipeline...")

# Load feature data
df = load_csv(FEATURE_DATA_CSV)
logger.info("Features loaded successfully.")

# Extract target and features
y = df['score'].values
X = df.drop(columns=['chrom', 'start', 'end', 'score']).values

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
logger.info(f"Data split into train ({len(X_train)}) and test ({len(X_test)}) samples.")

# Train Linear Regression
lr_model = train_linear_regression(X_train, y_train)
y_pred_lr = predict_linear_regression(lr_model, X_test)
lr_metrics = evaluate_regression(y_test, y_pred_lr)
logger.info("Linear Regression trained and evaluated.")

# Train Random Forest Regressor with simple hyperparameter tuning
best_mse = float('inf')
best_n_estimators = 100
for n in [100, 200, 300]:
    rf_model_candidate = train_random_forest_regressor(X_train, y_train, n_estimators=n, random_state=42)
    y_pred_rf_candidate = predict_random_forest_regressor(rf_model_candidate, X_test)
    candidate_metrics = evaluate_regression(y_test, y_pred_rf_candidate)
    if candidate_metrics['mse'] < best_mse:
        best_mse = candidate_metrics['mse']
        best_n_estimators = n

rf_model = train_random_forest_regressor(X_train, y_train, n_estimators=best_n_estimators, random_state=42)
y_pred_rf = predict_random_forest_regressor(rf_model, X_test)
rf_metrics = evaluate_regression(y_test, y_pred_rf)
logger.info(f"Random Forest trained and evaluated with n_estimators={best_n_estimators}.")

# CNN for Regression (assuming sequences are pre-encoded or use a real dataset)
seq_length = 100
X_train_seq = torch.randn(len(X_train), 4, seq_length)  # Placeholder
X_test_seq = torch.randn(len(X_test), 4, seq_length)
train_dataset = TensorDataset(X_train_seq, torch.tensor(y_train, dtype=torch.float32))
test_dataset = TensorDataset(X_test_seq, torch.tensor(y_test, dtype=torch.float32))

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_loader = DataLoader(train_dataset, batch_size=32, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

cnn_model = CNNRegressor(input_channels=4, seq_len=seq_length)
train_deep_model(cnn_model, train_loader, val_loader, epochs=5, lr=0.001, device='cpu')
y_pred_cnn = predict_deep_model(cnn_model, test_loader, device='cpu')
cnn_metrics = evaluate_regression(y_test, np.array(y_pred_cnn))
logger.info("CNN model trained and evaluated.")

# Ensemble predictions
y_pred_ensemble = (y_pred_lr + y_pred_rf + y_pred_cnn) / 3
ensemble_metrics = evaluate_regression(y_test, y_pred_ensemble)
logger.info("Ensemble predictions evaluated.")

# Generate plots
os.makedirs("report/regression_plots", exist_ok=True)
plot_distribution(y, "Distribution of Scores", "report/regression_plots/score_distribution.png")
plot_pred_vs_actual(y_test, y_pred_lr, "Linear Regression Predictions", "report/regression_plots/lr_pred_vs_actual.png")
plot_pred_vs_actual(y_test, y_pred_rf, "Random Forest Predictions", "report/regression_plots/rf_pred_vs_actual.png")
plot_pred_vs_actual(y_test, y_pred_cnn, "CNN Predictions", "report/regression_plots/cnn_pred_vs_actual.png")
plot_pred_vs_actual(y_test, y_pred_ensemble, "Ensemble Predictions", "report/regression_plots/ensemble_pred_vs_actual.png")

# Save metrics and plots as JSON for combined report
regression_results = {
    "Linear Regression": lr_metrics,
    "Random Forest": rf_metrics,
    "CNN": cnn_metrics,
    "Ensemble": ensemble_metrics
}

plots = {
    "score_distribution": "report/regression_plots/score_distribution.png",
    "lr_pred_vs_actual": "report/regression_plots/lr_pred_vs_actual.png",
    "rf_pred_vs_actual": "report/regression_plots/rf_pred_vs_actual.png",
    "cnn_pred_vs_actual": "report/regression_plots/cnn_pred_vs_actual.png",
    "ensemble_pred_vs_actual": "report/regression_plots/ensemble_pred_vs_actual.png"
}

with open("report/regression_metrics.json", 'w') as f:
    json.dump(regression_results, f, indent=4)

with open("report/regression_plots.json", 'w') as f:
    json.dump(plots, f, indent=4)

logger.info("Regression metrics and plots saved as JSON.")
logger.info("Regression pipeline completed.")
